# 外研版高中英语单词背诵 · 部署说明

这是一个**单文件静态网站**：`index.html` 已内置全部数据（342 对 / 103 错 / 96 错词），无需构建。

## 快速部署（3 步，全程网页操作）

详见 `guide.html`（打开照着做），要点：

1. **清空仓库 + 上传**：把 `index.html`、`guide.html`、`README.md` 上传到你的 GitHub 仓库
2. **开启 Pages**：Settings → Pages → Source 选 `Deploy from a branch` → Branch `main` / `/(root)` → Save
3. **验证**：访问 `https://你的用户名.github.io/` 显示统计即成功

## 文件说明

- `index.html` —— 网站本体（预构建，数据全在内）
- `guide.html` —— 部署指引（手机/电脑自适应，就 3 步）
- `README.md` —— 本说明
- `.nojekyll` —— 让 GitHub Pages 正常渲染（纯静态站点标配）
- `supabase/migrations.sql` —— Supabase 多设备实时同步建表 + RLS 策略 + Realtime 发布
- `.github/workflows/archive.yml` —— GitHub Actions 自动归档工作流（详见下文）
- `scripts/archive_manager.py` —— 归档管理器：带时间戳历史副本 + 索引 + 生命周期裁剪（被 workflow 调用，也可本地运行）
- `archive/` —— 历史归档（自动生成，含 `INDEX.json` / `INDEX.md`；**首次运行后才有**）

## 以后更新数据

改 `index.html` → 网页上传覆盖同名文件 → 约 30 秒自动上线。零命令行。

## 可选：多端同步（Supabase + GitHub 并存）

App 内「同步设置」面板支持**双后端并存**：

- **Supabase** —— 实时双向（毫秒级多设备同步，需自建项目 + `supabase/migrations.sql`）
- **GitHub** —— 免费归档后端（`data/vocab.json` 存到仓库，零成本）
- **双写并存** —— Supabase 为唯一实时真相源，GitHub 只做归档写入，永不对写、永不发生冲突

详见 `supabase/migrations.sql` 与 App 内「同步设置」。此功能可选，不影响网站上线。

## 可选：GitHub Actions 自动归档（推荐）

把「归档提交」从客户端移到**服务端定时执行**：省 PAT 配额、防 commit 风暴、可无人值守。

工作流每次运行会：① 写入最新快照 `data/vocab.json`；② 生成带时间戳副本 `archive/YYYY-MM-DD/HHMMSS.json`；
③ 维护 `archive/INDEX.json`（机器可读）+ `INDEX.md`（人可读表格）；④ 在 `README.md` 注入统计行；
⑤ Schema 校验，损坏快照会让 workflow 失败、**不污染历史**；⑥ 生命周期裁剪——保留「最近 30 份 + 每月保底 1 份」，与 App 端自动备份口径对齐。

> 去重幂等：内容与上次归档完全一致时自动跳过，重复运行不会产生垃圾快照。

### 启用（一次性）

1. 把本仓库完整上传（含 `.github/workflows/archive.yml`），GitHub 自动识别工作流
2. Settings → Actions → General → 「Workflow permissions」勾选 **Read and write permissions**（允许自动 commit）
3. 在 App「同步设置」→ GitHub 卡片 → **归档方式**选「通过 GitHub Actions」→ 保存

### 三种触发方式

| 触发 | 说明 | 需要 |
|---|---|---|
| `repository_dispatch`（推荐） | App 选「通过 Actions」后，每次归档自动发事件，服务端写文件 | Fine-grained PAT（Contents + Repository events 读写） |
| `workflow_dispatch` | GitHub UI → Actions → Run workflow 手动触发 | 默认 `GITHUB_TOKEN` |
| `schedule`（默认每 6 小时） | 无人值守定时归档 | 需配置下方 Supabase Secrets |

### Secrets（Settings → Secrets and variables → Actions）

- `GH_PAT` —— 仅 `repository_dispatch` 方式需要：能触发本仓库 workflow 的 Fine-grained PAT
- `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` / `SUPABASE_USER_ID` —— 仅 `schedule` 无人值守需要：让 runner 从 Supabase 拉取最新快照。**未配置时定时运行会自动跳过**（仅记录日志，不报错）

### 归档周期

默认每 6 小时一次，修改 `.github/workflows/archive.yml` 的 `cron` 表达式即可（如 `"0 8 * * *"` = 每天 08:00）。

> 提示：本工作流经 YAML 语法校验 + 端到端逻辑审查；因沙盒无法真实触发 GitHub Actions，建议在仓库内先手动跑一次 `workflow_dispatch` 验证，再把 PAT 填入 App 切到「通过 Actions」模式。
