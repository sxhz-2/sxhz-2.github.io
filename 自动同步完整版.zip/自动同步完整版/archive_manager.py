#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
archive_manager.py
=============================================================================
外研版单词背诵 · 归档管理器（供 GitHub Actions 调用，也可本地运行）

职责
----
把「最新快照」data/vocab.json 转换成**带时间戳的历史归档**，并维护索引与生命周期：

  1. 读取 data/vocab.json（若不存在/为空，则安全退出，不报错）
  2. Schema 校验 + 字段补全（兼容 v1/v2/v3 快照）
  3. 与最近一次归档做**内容比对**，完全相同则跳过 → 杜绝重复快照
  4. 写入带时间戳副本  archive/YYYY-MM-DD/HHMMSS.json
  5. 维护 archive/INDEX.json（机器可读）与 archive/INDEX.md（人可读）
  6. 生命周期裁剪：保留「最近 KEEP_RECENT 份」+「每月至少 1 份（月初那份）」
     —— 与 App 端 autoBackups 保留 30 份的逻辑对齐
  7. 在仓库 README.md 注入/更新一行统计徽标（幂等）

设计原则
--------
* 纯追加、永不覆盖历史：一旦落盘的快照不会被改写
* 幂等：重复运行结果一致，可放心放进 cron
* 零依赖：仅用标准库（json / hashlib / datetime / re / pathlib）
=============================================================================
"""
import hashlib
import json
import re
import sys
from datetime import datetime
from pathlib import Path

# ========================= 可调参数（环境变量可覆盖） =========================
REPO_ROOT     = Path(__file__).resolve().parent.parent
LATEST_PATH   = REPO_ROOT / "data" / "vocab.json"
ARCHIVE_DIR   = REPO_ROOT / "archive"
INDEX_JSON    = ARCHIVE_DIR / "INDEX.json"
INDEX_MD      = ARCHIVE_DIR / "INDEX.md"
KEEP_RECENT   = 30          # 始终保留的最近快照份数
KEEP_MONTHLY = True        # 是否在裁剪时每(年)月保底留 1 份


# ------------------------- 工具函数 ------------------------------------------
def log(msg):
    print(f"[archive] {msg}", flush=True)


def now():
    return datetime.now()


def canonical(snap: dict) -> str:
    """用于比对「内容是否变化」的规范序列化（排序 key、ensure_ascii=False）。"""
    return json.dumps(snap, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def load_latest(path: Path):
    """加载最新快照；不存在/为空/非法时返回 None（调用方据此安全退出）。"""
    if not path.exists():
        log(f"未找到最新快照 {path}，跳过归档")
        return None
    if path.stat().st_size == 0:
        log(f"最新快照为空 {path}，跳过归档")
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        log(f"⚠️ 最新快照 JSON 非法，跳过归档：{e}")
        return None
    if not isinstance(data, dict):
        log("⚠️ 快照根节点不是对象，跳过归档")
        return None
    return normalize(data)


def normalize(snap: dict) -> dict:
    """字段补全，兼容 v1/v2/v3，避免下游 KeyError。"""
    snap.setdefault("version", 3)
    snap.setdefault("dataVersion", 0)
    snap.setdefault("updatedAt", int(now().timestamp() * 1000))
    snap.setdefault("deviceId", "unknown")
    snap.setdefault("wrongBook", {})
    snap.setdefault("stats", {})
    snap.setdefault("masteredWords", {})
    snap.setdefault("totalCorrect", 0)
    snap.setdefault("totalWrong", 0)
    return snap


def snapshot_time(snap: dict) -> datetime:
    """快照的「逻辑时间」：优先 updatedAt，其次 _sessionDate，最后文件 mtime。"""
    ts = snap.get("updatedAt")
    if isinstance(ts, (int, float)) and ts > 0:
        try:
            return datetime.fromtimestamp(ts / 1000.0)
        except (ValueError, OSError):
            pass
    ds = snap.get("_sessionDate")
    if isinstance(ds, str) and ds[:10]:
        try:
            return datetime.strptime(ds[:10], "%Y-%m-%d")
        except ValueError:
            pass
    return now()


def derive_stats(snap: dict) -> dict:
    """从快照派生展示用统计（与 App 端口径一致）。"""
    wrong_book = snap.get("wrongBook", {}) or {}
    stats = snap.get("stats", {}) or {}
    total_c = sum(int(v.get("totalCorrect", 0)) for v in [snap])
    total_w = sum(int(v.get("totalWrong", 0)) for v in [snap])
    # 今日/月听写量：取最新日期桶
    latest_day = ""
    for k in stats:
        if latest_day < k:
            latest_day = k
    day_c = day_w = 0
    if latest_day:
        b = (stats.get(latest_day) or {})
        day_c = int(b.get("c", 0))
        day_w = int(b.get("w", 0))
    return {
        "wrongCount": len(wrong_book),
        "totalCorrect": int(snap.get("totalCorrect", 0)),
        "totalWrong": int(snap.get("totalWrong", 0)),
        "todayTotal": day_c + day_w,
        "latestDay": latest_day,
        "dataVersion": int(snap.get("dataVersion", 0)),
    }


def month_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m")


# ------------------------- 索引读写 ------------------------------------------
def load_index() -> list:
    if not INDEX_JSON.exists():
        return []
    try:
        data = json.loads(INDEX_JSON.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def save_index(entries: list):
    INDEX_JSON.write_text(
        json.dumps(entries, ensure_ascii=False, indent=2, sort_keys=False),
        encoding="utf-8",
    )


# ------------------------- 生命周期裁剪 --------------------------------------
def prune(entries: list) -> list:
    """
    裁剪规则（与 App 端 autoBackups 保留 30 份对齐）：
    * 始终保留最近 KEEP_RECENT 份（按时间倒序）
    * 若 KEEP_MONTHLY：对每个 (年)月，额外保底保留该月最早的一份
      （即便它落在「最近 N 份」之外，也不删）—— 形成月度时间轴
    """
    if not entries:
        return entries
    # 按时间升序处理
    ordered = sorted(entries, key=lambda e: e.get("time", ""))
    recent = set(range(len(ordered) - KEEP_RECENT, len(ordered)))
    recent = {i for i in recent if i >= 0}

    keep = set(recent)
    if KEEP_MONTHLY:
        earliest_of_month = {}
        for i, e in enumerate(ordered):
            m = e.get("month") or month_key(
                datetime.strptime(e["time"][:19], "%Y-%m-%dT%H:%M:%S")
                if e.get("time") else now()
            )
            if m not in earliest_of_month:
                earliest_of_month[m] = i
        keep.update(earliest_of_month.values())

    survivors = [ordered[i] for i in range(len(ordered)) if i in keep]
    removed = [ordered[i] for i in range(len(ordered)) if i not in keep]
    # 删除被淘汰的归档文件
    for e in removed:
        fp = REPO_ROOT / e.get("path", "")
        if fp.exists():
            try:
                fp.unlink()
                log(f"  淘汰旧归档 {e['path']}")
            except OSError as ex:
                log(f"  ⚠️ 无法删除 {fp}：{ex}")
    return survivors


# ------------------------- 索引渲染 ------------------------------------------
MD_HEADER = """# 归档索引（自动生成，勿手动编辑）

> 本目录由 GitHub Actions 自动维护：每次归档生成一份带时间戳的快照，
> 保留「最近 {recent} 份 + 每月保底 1 份」。最新数据始终见 [`../data/vocab.json`](../data/vocab.json)。

| 时间 | 文件 | 版本 | 错词 | 今日总量 |
|---|---|---|---|---|
""".strip()


def render_index_md(entries: list, stats: dict) -> str:
    lines = [MD_HEADER.format(recent=KEEP_RECENT)]
    if not entries:
        lines.append("\n_暂无归档，等待首次同步…_")
    else:
        # 时间倒序展示
        for e in sorted(entries, key=lambda x: x.get("time", ""), reverse=True):
            t = (e.get("time") or "").replace("T", " ").replace("Z", "")[:16]
            fname = Path(e.get("path", "")).name
            rel = f"[`{fname}`]({fname})"
            lines.append(
                f"| {t} | {rel} | v{e.get('dataVersion', '-')} "
                f"| {e.get('wrongCount', '-')} | {e.get('todayTotal', '-')} |"
            )
    lines.append("")
    lines.append(f"_最新快照：dataVersion **{stats.get('dataVersion','-')}**，"
                 f"错词 {stats.get('wrongCount','-')}，"
                 f"今日总量 {stats.get('todayTotal','-')}_")
    return "\n".join(lines) + "\n"


# ------------------------- README 统计注入 -----------------------------------
README_PATH = REPO_ROOT / "README.md"
STATS_RE = re.compile(
    r"<!--ARCHIVE_STATS_START-->.*?<!--ARCHIVE_STATS_END-->",
    re.DOTALL,
)


def update_readme_stats(stats: dict):
    if not README_PATH.exists():
        return
    text = README_PATH.read_text(encoding="utf-8")
    badge = (
        f"<!--ARCHIVE_STATS_START-->"
        f"📚 归档快照 **{stats.get('dataVersion','-')}** · "
        f"错词 **{stats.get('wrongCount','-')}** · "
        f"今日总量 **{stats.get('todayTotal','-')}** · "
        f"更新于 `{now().strftime('%Y-%m-%d %H:%M')}`"
        f"<!--ARCHIVE_STATS_END-->"
    )
    if STATS_RE.search(text):
        text = STATS_RE.sub(badge, text)
    else:
        text = text.rstrip() + "\n\n" + badge + "\n"
    README_PATH.write_text(text, encoding="utf-8")


# ------------------------- 主流程 --------------------------------------------
def main():
    global LATEST_PATH, REPO_ROOT, ARCHIVE_DIR, INDEX_JSON, INDEX_MD, README_PATH
    # 支持环境变量覆盖根目录（便于测试 / CI 复用）
    env_root = os_env("REPO_ROOT")
    if env_root:
        REPO_ROOT = Path(env_root).resolve()
    # 始终从 REPO_ROOT 推导派生路径，保证运行时覆盖一定生效
    LATEST_PATH = REPO_ROOT / "data" / "vocab.json"
    ARCHIVE_DIR = REPO_ROOT / "archive"
    INDEX_JSON  = ARCHIVE_DIR / "INDEX.json"
    INDEX_MD    = ARCHIVE_DIR / "INDEX.md"
    README_PATH = REPO_ROOT / "README.md"

    snap = load_latest(LATEST_PATH)
    if snap is None:
        # 无快照不算失败：cron 空跑时应安全退出
        return 0

    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    # 与最近一次归档比对：内容完全一致则跳过，避免重复快照
    entries = load_index()
    canon = canonical(snap)
    if entries:
        last = entries[-1]
        last_fp = REPO_ROOT / last.get("path", "")
        if last_fp.exists():
            last_canon = canonical(json.loads(last_fp.read_text(encoding="utf-8")))
            if last_canon == canon:
                log("内容与前次归档完全一致，跳过（幂等）")
                return 0

    # 生成带时间戳的归档副本
    dt = snapshot_time(snap)
    stamp = dt.strftime("%Y-%m-%d/%H%M%S")
    dest = ARCHIVE_DIR / f"{stamp}.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(
        json.dumps(snap, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    stats = derive_stats(snap)
    entry = {
        "time": dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "month": month_key(dt),
        "path": str(dest.relative_to(REPO_ROOT)).replace("\\", "/"),
        "dataVersion": stats["dataVersion"],
        "wrongCount": stats["wrongCount"],
        "todayTotal": stats["todayTotal"],
        "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()[:12],
    }
    entries.append(entry)

    # 裁剪 + 落盘
    entries = prune(entries)
    save_index(entries)
    INDEX_MD.write_text(render_index_md(entries, stats), encoding="utf-8")
    update_readme_stats(stats)

    log(f"✅ 新归档 {entry['path']}（dataVersion={stats['dataVersion']}，"
        f"错词={stats['wrongCount']}，今日总量={stats['todayTotal']}）")
    log(f"   保留快照 {len(entries)} 份（最近 {KEEP_RECENT} + 每月保底）")
    return 0


def os_env(name: str) -> str:
    import os
    return os.environ.get(name, "").strip()


if __name__ == "__main__":
    sys.exit(main())
