-- =============================================================
-- 外研版单词背诵 · Supabase 同步 建表 + 多设备实时同步 迁移
-- 用法：Supabase 后台 → SQL Editor → 粘贴全部 → Run
-- 前置：已创建项目并取得 URL + Anon Key（填入 App「同步设置」）
-- =============================================================

-- 1) 三张表（若已存在则跳过）
create table if not exists public.vocab_progress (
  user_id text not null, book text not null default '', unit text not null default '',
  word text not null, correct_count int not null default 0, wrong_count int not null default 0,
  last_practiced timestamptz, primary key (user_id, word)
);
create table if not exists public.wrong_words (
  user_id text not null, word text not null, meaning text default '', phonetic text default '',
  pos text default '', last_input text default '', wrong_count int not null default 0, fixed boolean not null default false,
  primary key (user_id, word)
);
create table if not exists public.study_sessions (
  user_id text not null, date date not null, correct_count int not null default 0, wrong_count int not null default 0,
  words_practiced int not null default 0, mastered_words text, session_correct int, session_wrong int,
  session_updated_at double precision, data_version bigint not null default 0,
  primary key (user_id, date)
);

-- 2) study_sessions 兼容旧版的扩展列（幂等，可反复执行）
alter table public.study_sessions
  add column if not exists session_correct integer not null default 0,
  add column if not exists session_wrong integer not null default 0,
  add column if not exists session_updated_at numeric,
  add column if not exists data_version bigint not null default 0;
create index if not exists idx_study_sessions_data_version on public.study_sessions(user_id, date, data_version desc);

-- 3) ★★★ 关键：启用 RLS 后必须配 policy，否则 anon/authenticated 写入被拒(42501) ★★★
--    App 的「连接测试」用 select head:true 能通过，恰好掩盖写入被拦，
--    导致「立即上传」永远失败、多设备无法同步。
alter table public.vocab_progress enable row level security;
alter table public.wrong_words enable row level security;
alter table public.study_sessions enable row level security;

create policy if not exists "vocab_progress_owner" on public.vocab_progress
  for all to authenticated using (auth.uid()::text = user_id) with check (auth.uid()::text = user_id);
create policy if not exists "wrong_words_owner" on public.wrong_words
  for all to authenticated using (auth.uid()::text = user_id) with check (auth.uid()::text = user_id);
create policy if not exists "study_sessions_owner" on public.study_sessions
  for all to authenticated using (auth.uid()::text = user_id) with check (auth.uid()::text = user_id);

grant all on public.vocab_progress to authenticated;
grant all on public.wrong_words to authenticated;
grant all on public.study_sessions to authenticated;

-- 4) Realtime 实时同步：副本标识 + 加入实时发布
--    配合前端 setupRealtime()，任一设备写入即推送至其它在线设备
alter table public.vocab_progress replica identity full;
alter table public.wrong_words replica identity full;
alter table public.study_sessions replica identity full;
alter publication supabase_realtime add table public.vocab_progress;
alter publication supabase_realtime add table public.wrong_words;
alter publication supabase_realtime add table public.study_sessions;
